package com.example.libraryapp.model;




public class Student {
    private long id;
    private String username;
    private String email;

    private String cellPhone;
    private int cin;
    private String description ;
    private int booksNumber ;
    private String privileges ;
    private static int maxBorrowed ;
    private int flagged ;


    public Student( String username, String email, String cellPhone) {
        this.username = username;
        this.email = email;
        this.cellPhone = cellPhone;
    }

    public long getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getCellPhone() {
        return cellPhone;
    }

    public int getCin() {
        return cin;
    }

    public static int getMaxBorrowed() {
        return maxBorrowed;
    }

    public String getPrivileges() {
        return privileges;
    }

    public String getDescription() {
        return description;
    }

    public int getBooksNumber() {
        return booksNumber;
    }

    public int getFlagged() {
        return flagged;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setCellPhone(String cellPhone) {
        this.cellPhone = cellPhone;
    }

    public void setCin(int cin) {
        this.cin = cin;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setBooksNumber(int booksNumber) {
        this.booksNumber = booksNumber;
    }

    public void setPrivileges(String privileges) {
        this.privileges = privileges;
    }

    public static void setMaxBorrowed(int maxBorrowed) {
        Student.maxBorrowed = maxBorrowed;
    }

    public void setFlagged(int flagged) {
        this.flagged = flagged;
    }

}

