package com.example.libraryapp.model;

public class Book {
    private int id ;
    private String title ;
    private String authorName ;
    private String genre ;
    private String edition ;
    private String isbn ;
    private int stars ;
    private String language ;
    private String isDeleted ;
    private long copiesNumber ;


    public Book(String title, String authorName, String genre, String edition, String isbn, String language) {
        this.title = title;
        this.authorName = authorName;
        this.genre = genre;
        this.edition = edition;
        this.isbn = isbn;
        this.language = language;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getEdition() {
        return edition;
    }

    public void setEdition(String edition) {
        this.edition = edition;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public int getStars() {
        return stars;
    }

    public void setStars(int stars) {
        this.stars = stars;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    public long getCopiesNumber() {
        return copiesNumber;
    }

    public void setCopiesNumber(long copiesNumber) {
        this.copiesNumber = copiesNumber;
    }
}
