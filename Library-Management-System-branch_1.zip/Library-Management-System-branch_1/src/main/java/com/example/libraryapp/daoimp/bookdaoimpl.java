package com.example.libraryapp.daoimp;

import com.example.libraryapp.model.Book;
import com.example.libraryapp.model.Student;

import java.sql.Statement;

public class bookdaoimpl {
    public void save(Book b) {
        connexionDB conDb = new connexionDB();

        Statement st ;
        try {
            st = conDb.getCon().createStatement();
            String req="INSERT INTO Book values("+b.getTitle()+"','"+b.getAuthorName()+"','"+b.getGenre()+"','"+b.getGenre()+"','"+b.getIsbn()+"','"+b.getLanguage()+"');";
            st.executeUpdate(req);
            conDb.getCon().close();
        }catch (Exception ec){
            ec.printStackTrace();
        }
    }
}
