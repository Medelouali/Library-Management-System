package com.example.libraryapp.daoimp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class connexionDB {
    private Connection con;

    public Connection getCon() {
        return con;
    }

    public void setCon(Connection con) {
        this.con = con;
    }

    public connexionDB() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bibliotheque?useSSL=false&allowPublicKeyRetrieval=true", "root", "");
            System.out.println("Connection OK");
        }catch (ClassNotFoundException ex){
            ex.printStackTrace();

        }catch (SQLException sqex){
            sqex.printStackTrace();
        }
    }





}
