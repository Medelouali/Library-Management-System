
package com.example.libraryapp.controller;



import com.example.libraryapp.LmsApplication;
import com.example.libraryapp.daoimp.studentdaoimpl;
import com.example.libraryapp.model.Student;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class NewStudentController {

    private Stage stage;
    private Scene scene;
    private Parent root;


    @FXML
    private TextField UserName;

    @FXML
    private TextField Email;
    @FXML
    private TextField Cellphone;






    @FXML
    public void NewBook(ActionEvent event) {
        try{
            this.switchPage(event, "new-book-view.fxml");
        }catch (Exception e){
            e.printStackTrace();
        }

    }


    @FXML
    public void Transactions(ActionEvent event) {
        try{
            this.switchPage(event, "transactions-view.fxml");
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    @FXML
    public void IssueBook(ActionEvent event) {
        try{
            this.switchPage(event, "issue-book-view.fxml");
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public void ReturnBook(ActionEvent event) {
        try{
            this.switchPage(event, "return-book-view.fxml");
        }catch (Exception e){
            e.printStackTrace();
        }

    }


    public void AddCopies(ActionEvent event) {
        try{
            this.switchPage(event, "add-copies-view.fxml");
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public void Books(ActionEvent event) {
        try{
            this.switchPage(event, "book-views.fxml");
        }catch (Exception e){
            e.printStackTrace();
        }

    }
    public void Students(ActionEvent event) {
        try{
            this.switchPage(event, "students-view.fxml");
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public void Statistics(ActionEvent event) {
        try{
            this.switchPage(event, "statistics.fxml");
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public void Settings(ActionEvent event) {
        try{
            this.switchPage(event, "settings.fxml");
        }catch (Exception e){
            e.printStackTrace();
        }

    }
    public void Logout(ActionEvent event) {
        try{
            this.switchPage(event, "logout-view.fxml");
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public void switchPage(ActionEvent event, String pageName) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(LmsApplication.class.getResource(pageName));
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setWidth(700);
        stage.setHeight(550);
        stage.show();
    }

    public void SaveStudent(){

        Student student = new Student(UserName.getText(),Email.getText(), Cellphone.getText() );
        studentdaoimpl dao = new studentdaoimpl();

        dao.save(student);}  // on a instancie de Studentdao pour pouvoir appeler la mathode : save



}
