package com.example.libraryapp.daoimp;



import com.example.libraryapp.model.Student;

import java.sql.Statement;

public class studentdaoimpl {

      public void save(Student e) {
        connexionDB conDb = new connexionDB();

        Statement st ;
        try {
            st = conDb.getCon().createStatement();
            String req="INSERT INTO Student values("+e.getUsername()+"','"+e.getEmail()+"','"+e.getCellPhone()+"');"; //get prenom ...Student parce qu'on a instancie un objet etudiant avec les donnees entres par l utilisateur
            st.executeUpdate(req);
            conDb.getCon().close();
        }catch (Exception ec){
            ec.printStackTrace();
        }
    }
}
